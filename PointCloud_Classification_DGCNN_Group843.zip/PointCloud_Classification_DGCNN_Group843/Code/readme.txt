This implementation is done by group 843, for the course Image Processing and Computer Vision 2020.
 It is an implementation based om the Dynamic Graph CNN, inspired by https://github.com/WangYueFt/dgcnn

Before running you need to download the data from http://modelnet.cs.princeton.edu/ModelNet40.zip, and put it into the data folder

To run the training, run the main.py. All the parameters we used, is already set in the begining of the script

In the folder 'Model and Results' files with the model, accuracy and loss can be found. Here there is also a script 'graph.py' which is used 
to generate the graphs used in the report.

